import { useState } from 'react';

// adjacency for a 3×3 grid, including diagonals
const ADJ = {
  0: [1,3,4],
  1: [0,2,3,4,5],
  2: [1,4,5],
  3: [0,1,4,6,7],
  4: [0,1,2,3,5,6,7,8],
  5: [1,2,4,7,8],
  6: [3,4,7],
  7: [3,4,5,6,8],
  8: [4,5,7],
};


function Square({value, onSquareClick}) {
  return (
    <button className="square" onClick={onSquareClick}>
      {value}
    </button>
  );
}

export default function Board() {
  const [xIsNext, setXIsNext] = useState(true);
  const [squares, setSquares] = useState(Array(9).fill(null));
  const [xQueue, setXQ] = useState([]);
  const [oQueue, setOQ] = useState([]);
  const [phase2, setPhase2] = useState(false);
  const [selectedPiece, setSelected] = useState(null);


  const [moveQueue, setMoveQueue] = useState([]);  // <<-- NEW queue inside Board!

  function enqueue(move) {
    setMoveQueue(prevQueue => [...prevQueue, move]);
  }

  function dequeue() {
    setMoveQueue(prevQueue => prevQueue.slice(1));
  }

  function handleClick(i) {
    if (calculateWinner(squares)) {
      return;
    }

    if (!phase2){ //phase 1
      if (squares[i]) return;
      const nextSquares = squares.slice(); 
      
      if (xIsNext) {
        if (xQueue.length >= 3) return; 
        nextSquares[i] = 'X';
        setXQ(prev => [...xQueue, i]); 
      } 
      else {
        if (oQueue.length >= 3) return; 
        nextSquares[i] = 'O';
        setOQ(prev => [...oQueue, i]);
      }

      setSquares(nextSquares);
      setXIsNext(!xIsNext);

      if ((xQueue.length + 1 === 3 && oQueue.length === 3) 
        || (oQueue.length + 1 === 3 && xQueue.length === 3)){
          setPhase2(true);  
      }
      return; 
    }
    if (phase2){ //phase 2
      if (selectedPiece === null) {
        if ((xIsNext && squares[i] === 'X') ||
          (!xIsNext && squares[i] === 'O')) 
          {
          setSelected(i);
        }
        return;
      }

      const CENTER = 4;
      const centerOwner = squares[CENTER];

      let enforceCenterRule = false;
      if (centerOwner === 'X') {
        if (xIsNext === true) {
          enforceCenterRule = true;
        }
      } else if (centerOwner === 'O') {
        if (xIsNext === false) {
          enforceCenterRule = true;
        }
      }

      if (centerOwner !== null && enforceCenterRule === true) {
        if (selectedPiece !== CENTER) {
          if (ADJ[selectedPiece].indexOf(i) === -1 ||
            squares[i] !== null) {
              setSelected(null);
              return;
            }
            const temp = squares.slice();
            temp[selectedPiece] = null;
            temp[i]             = xIsNext ? 'X' : 'O';
            if (!calculateWinner(temp)) {
              setSelected(null);
              return;
            }
          }
        }

      if (!ADJ[selectedPiece].includes(i) || squares[i] !== null) {
        setSelected(null);
        return;
      }

      const next = squares.slice();
      next[selectedPiece] = null;
      if (xIsNext) {
        next[i] = 'X';
      } else {
        next[i] = 'O';
      }
      setSquares(next);

      if (xIsNext) {
        setXQ(queue => 
          queue.map(p => {
            if (p === selectedPiece) {
              return i;
            }
            return p;
          })
        );
      } else {
        setOQ(queue => 
          queue.map(p => {
            if (p === selectedPiece) {
              return i;
            }
            return p;
          })
        );
      }

      setSelected(null);
      setXIsNext(!xIsNext);
    }
  }

  const winner = calculateWinner(squares);
  let status;
  if (winner) {
    status = 'Winner: ' + winner;
  } else if (phase2 && selectedPiece !== null) {
    status = `Move ${xIsNext ? 'X' : 'O'} from ${selectedPiece}.`;
  } else {
    status = 'Next player: ' + (xIsNext ? 'X' : 'O');
  }

  return (
    <>
      <div className="status">{status}</div>
      <div className="board-row">
        {[0,1,2].map(i => (
          <Square
            key={i}
            value={squares[i]}
            isSelected={i === selectedPiece}
            onSquareClick={() => handleClick(i)}
          />
        ))}
      </div>
      <div className="board-row">
        {[3,4,5].map(i => (
          <Square
            key={i}
            value={squares[i]}
            isSelected={i === selectedPiece}
            onSquareClick={() => handleClick(i)}
          />
        ))}
      </div>
      <div className="board-row">
        {[6,7,8].map(i => (
          <Square
            key={i}
            value={squares[i]}
            isSelected={i === selectedPiece}
            onSquareClick={() => handleClick(i)}
          />
        ))}
      </div>
    </>
  );
}

function calculateWinner(squares) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  return null;
}